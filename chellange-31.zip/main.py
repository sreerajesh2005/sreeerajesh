def linearSearchProduct(productlist, targetProduct):
    indices = []

    for index, product in enumerate(productlist):
        if product == targetProduct:
            indices.append(index)

    return indices

product = ["rajesh", "abhi", "Akash", "Surya"]
target = "rajesh"
target2 = "Akash"
result = linearSearchProduct(product, target)
result2 = linearSearchProduct(product, target2)
print(result)
print(result2)
